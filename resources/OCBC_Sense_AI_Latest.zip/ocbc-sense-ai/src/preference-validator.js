
const allowedActions = {
  increase_text_size: ["large"],
  decrease_text_size: ["small"],
  simplify_language: [true],
  change_language: ["en", "zh", "ms", "ta"],
  read_aloud: [true]
};

function validatePreference(action, value) {
  if (!Object.prototype.hasOwnProperty.call(
    allowedActions,
    action
  )) {
    return false;
  }

  return allowedActions[action].includes(value);
}

module.exports = { validatePreference };
