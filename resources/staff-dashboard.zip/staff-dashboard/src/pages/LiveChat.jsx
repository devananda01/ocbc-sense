
import { useState } from "react";
import {
  Search,
  Send,
  Paperclip,
  Phone,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  MessageSquare,
  Lightbulb,
  ArrowLeft
} from "lucide-react";

import "./LiveChat.css";

const initialChats = [
  {
    id: "472",
    phone: "5---S31A",
    status: "Attention Needed",
    step: "Step 3: Document NFC Scan",
    preview: "My passport NFC scan keeps failing",
    time: "Just now",
    unread: 1,
    messages: [
      {
        sender: "customer",
        text: "I've tried scanning my passport three times, but it keeps failing. Can you help?",
        time: "14:28"
      }
    ]
  },
  {
    id: "491",
    phone: "5---7988",
    status: "Attention Needed",
    step: "Step 3: Document NFC Scan",
    preview: "My phone keeps failing with the card",
    time: "Just now",
    unread: 1,
    messages: [
      {
        sender: "customer",
        text: "Hi, every time I tap my IC to the phone, it says read failed. I've tried twice already and it won't proceed.",
        time: "14:24"
      },
      {
        sender: "staff",
        text: "Hello! Please try placing the top edge of your phone flat against the chip on the card and hold it still for 4 seconds without moving. Thick cases may also block the sensor.",
        time: "14:25"
      },
      {
        sender: "customer",
        text: "Let me take off my phone case and test again right now.",
        time: "14:26"
      }
    ]
  },
  {
    id: "488",
    phone: "1---142C",
    status: "In Progress",
    step: "Step 2: Mobile OTP Verification",
    preview: "Did not receive SMS code yet",
    time: "3m ago",
    unread: 1,
    messages: [
      {
        sender: "customer",
        text: "I haven't received my SMS verification code yet.",
        time: "14:20"
      }
    ]
  },
  {
    id: "485",
    phone: "5---890F",
    status: "In Progress",
    step: "Step 4: Initial Deposit",
    preview: "Can I use PayNow or Wise?",
    time: "8m ago",
    unread: 0,
    messages: [
      {
        sender: "customer",
        text: "Can I use PayNow or Wise for my initial deposit?",
        time: "14:17"
      }
    ]
  },
  {
    id: "479",
    phone: "3---C53A",
    status: "In Progress",
    step: "Step 3: Document NFC Scan",
    preview: "I need help scanning my passport",
    time: "5m ago",
    unread: 0,
    messages: [
      {
        sender: "customer",
        text: "Hi, I'm having trouble scanning my passport. Can you help me?",
        time: "14:20"
      }
    ]
  }
];

function LiveChat({
  onBack,
  initialApplicantId = "491"
}) {
  const [chats, setChats] = useState(initialChats);

  const [selectedId, setSelectedId] = useState(
    initialChats.some(
      (chat) => chat.id === String(initialApplicantId)
    )
      ? String(initialApplicantId)
      : "491"
  );

  const [message, setMessage] = useState("");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [typing, setTyping] = useState(true);

  const selectedChat = chats.find(
    (chat) => chat.id === selectedId
  );

  const activeChats = chats.filter(
    (chat) => chat.status !== "Resolved"
  );

  const filteredChats = activeChats.filter((chat) => {
    const matchesSearch =
      chat.id.includes(search) ||
      chat.preview
        .toLowerCase()
        .includes(search.toLowerCase());

    const matchesFilter =
      filter === "All" ||
      (filter === "Attention Needed" &&
        chat.status === "Attention Needed") ||
      (filter === "In Progress" &&
        chat.status === "In Progress");

    return matchesSearch && matchesFilter;
  });

  // SEND MESSAGE
  const sendMessage = () => {
    if (!message.trim()) return;

    if (
      !selectedChat ||
      selectedChat.status === "Resolved"
    ) {
      return;
    }

    const newMessage = {
      sender: "staff",
      text: message.trim(),
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
      })
    };

    setChats((previous) =>
      previous.map((chat) =>
        chat.id === selectedId
          ? {
              ...chat,
              preview: newMessage.text,
              messages: [
                ...chat.messages,
                newMessage
              ]
            }
          : chat
      )
    );

    setMessage("");
    setTyping(false);
  };

  // RESOLVE CHAT
  const resolveChat = () => {
    if (
      !selectedChat ||
      selectedChat.status === "Resolved"
    ) {
      return;
    }

    const remainingChats = chats.filter(
      (chat) =>
        chat.id !== selectedId &&
        chat.status !== "Resolved"
    );

    setChats((previous) =>
      previous.map((chat) =>
        chat.id === selectedId
          ? {
              ...chat,
              status: "Resolved",
              unread: 0
            }
          : chat
      )
    );

    setMessage("");
    setTyping(false);
    setFilter("All");
    setSearch("");

    if (remainingChats.length > 0) {
      setSelectedId(remainingChats[0].id);
    } else {
      onBack?.();
    }
  };

  // SELECT CHAT
  const selectChat = (id) => {
    setSelectedId(id);
    setMessage("");
    setTyping(false);

    setChats((previous) =>
      previous.map((chat) =>
        chat.id === id
          ? {
              ...chat,
              unread: 0
            }
          : chat
      )
    );
  };

  return (
    <div className="lc-page">
      {/* TOP BAR */}
      <header className="lc-topbar">
        <div className="lc-brand">
          <strong className="lc-logo">
            OCBC
          </strong>

          <div>
            <strong>
              Digital Onboarding Assist
            </strong>

            <small>
              LIVE CHAT CONSOLE · /staff/chat
            </small>
          </div>
        </div>

        {/* BACK TO FRICTION QUEUE */}
        <button
          type="button"
          className="lc-back-tab"
          onClick={onBack}
        >
          <ArrowLeft size={15} />
          Live Friction Queue
        </button>

        <span className="lc-online">
          ● {activeChats.length} Active Applicant Conversations
        </span>

        <div className="lc-top-right">
          <span className="lc-audio">
            Audio Alerts: ON
          </span>

          <span className="lc-staff-avatar">
            SL
          </span>

          <div>
            <strong>Sherry Lim</strong>
            <small>
              Customer Support Executive
            </small>
          </div>
        </div>
      </header>

      <div className="lc-layout">
        {/* LEFT CHAT LIST */}
        <aside className="lc-sidebar">
          <div className="lc-sidebar-heading">
            <strong>Active Chats</strong>
            <span>{activeChats.length}</span>
          </div>

          <div className="lc-search">
            <Search size={15} />

            <input
              placeholder="Filter by Applicant ID..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
            />
          </div>

          <div className="lc-filters">
            {[
              "All",
              "Attention Needed",
              "In Progress"
            ].map((item) => (
              <button
                key={item}
                className={
                  filter === item ? "active" : ""
                }
                onClick={() => setFilter(item)}
              >
                {item}
              </button>
            ))}
          </div>

          <div className="lc-chat-list">
            {filteredChats.map((chat) => (
              <button
                key={chat.id}
                className={`lc-chat-item ${
                  selectedId === chat.id
                    ? "selected"
                    : ""
                }`}
                onClick={() =>
                  selectChat(chat.id)
                }
              >
                <div className="lc-chat-avatar">
                  {chat.id.slice(-3)}
                </div>

                <div className="lc-chat-preview">
                  <div className="lc-chat-name">
                    <strong>
                      Applicant #{chat.id}
                    </strong>

                    <span>
                      {chat.time}
                    </span>
                  </div>

                  <small>
                    {chat.step}
                  </small>

                  <p>
                    {chat.preview}
                  </p>
                </div>

                {chat.unread > 0 && (
                  <span className="lc-unread">
                    {chat.unread}
                  </span>
                )}
              </button>
            ))}

            {filteredChats.length === 0 && (
              <div
                style={{
                  padding: "16px",
                  color: "#94a3b8",
                  fontSize: "11px"
                }}
              >
                No active conversations found.
              </div>
            )}
          </div>
        </aside>

        {/* MAIN CHAT */}
        <main className="lc-main">
          <div className="lc-customer-header">
            <div className="lc-customer-identity">
              <div className="lc-customer-avatar">
                A{selectedChat?.id}
              </div>

              <div>
                <h2>
                  Applicant #{selectedChat?.id}
                </h2>

                <p>
                  {selectedChat?.phone} · Active Now
                </p>

                <small>
                  {selectedChat?.step} · Friction Alerts: 2
                </small>
              </div>
            </div>

            <div className="lc-case-actions">
              <button
                className="lc-escalate"
                onClick={() =>
                  alert(
                    `Escalate Applicant #${selectedChat?.id}`
                  )
                }
              >
                <Phone size={14} />
                Escalate Case
              </button>

              <button
                className="lc-resolve"
                onClick={resolveChat}
                disabled={!selectedChat}
              >
                <CheckCircle2 size={14} />
                Resolve & Close Chat
              </button>
            </div>
          </div>

          {/* CONVERSATION */}
          <div className="lc-conversation">
            <div className="lc-date-divider">
              Today
            </div>

            {selectedChat?.id === "491" && (
              <div className="lc-system-alert">
                <AlertTriangle size={15} />

                <span>
                  Friction detected: NFC Scan Timeout
                  (Error Code: NFC_TIMEOUT_04).
                  Sherry Lim joined the session
                  to assist applicant.
                </span>

                <small>
                  14:24:12
                </small>
              </div>
            )}

            {selectedChat?.id === "472" && (
              <div className="lc-system-alert">
                <AlertTriangle size={15} />

                <span>
                  Friction detected: NFC Failure
                  Limit Exceeded (3/3).
                  Sherry Lim joined the session
                  to assist applicant.
                </span>

                <small>
                  14:28:00
                </small>
              </div>
            )}

            <div className="lc-messages">
              {selectedChat?.messages.map(
                (item, index) => (
                  <div
                    key={index}
                    className={`lc-message-row ${item.sender}`}
                  >
                    <div className="lc-message-content">
                      <div className="lc-message-meta">
                        <strong>
                          {item.sender === "staff"
                            ? "Sherry Lim"
                            : `Applicant #${selectedChat.id}`}
                        </strong>

                        <span>
                          {item.time}
                        </span>
                      </div>

                      <div className="lc-bubble">
                        {item.text}
                      </div>

                      {item.sender === "staff" && (
                        <small className="lc-delivered">
                          ✓ Delivered · Read by applicant
                        </small>
                      )}
                    </div>
                  </div>
                )
              )}
            </div>

            {typing &&
              selectedChat?.id === "491" && (
                <div className="lc-typing">
                  <span>● ● ●</span>
                  Applicant #491 is typing...
                </div>
              )}
          </div>

          {/* SUGGESTED RESPONSES */}
          <div className="lc-suggestions">
            <Lightbulb size={14} />

            <span>
              Suggested:
            </span>

            {[
              "Hold phone flat over IC",
              "Remove thick phone cover",
              "Try Singpass MyInfo instead",
              "Session refreshed, please retry"
            ].map((suggestion) => (
              <button
                key={suggestion}
                onClick={() =>
                  setMessage(suggestion)
                }
              >
                {suggestion}
              </button>
            ))}
          </div>

          {/* MESSAGE INPUT */}
          <div className="lc-input-area">
            <button
              className="lc-attach"
              type="button"
              onClick={() =>
                alert(
                  "Attachment feature coming soon"
                )
              }
            >
              <Paperclip size={17} />
            </button>

            <button
              className="lc-attach"
              type="button"
              onClick={() =>
                alert(
                  "Quick replies coming soon"
                )
              }
            >
              <MessageSquare size={17} />
            </button>

            <input
              placeholder={`Type a response to Applicant #${selectedChat?.id}...`}
              value={message}
              onChange={(e) =>
                setMessage(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  sendMessage();
                }
              }}
              disabled={!selectedChat}
            />

            <button
              className="lc-send"
              type="button"
              onClick={sendMessage}
              disabled={
                !selectedChat ||
                !message.trim()
              }
            >
              <Send size={17} />
            </button>
          </div>

          {/* FOOTER */}
          <footer className="lc-footer">
            <span>
              <ShieldCheck size={12} />
              End-to-end encrypted session
            </span>

            <span>
              OCBC Assist v3.4.1 ·
              Gateway: SG-MAS-PRD
            </span>
          </footer>
        </main>
      </div>
    </div>
  );
}

export default LiveChat;