
import { useState } from "react";
import {
  UserRound,
  Clock3,
  AlertTriangle,
  Ban,
  EyeOff,
  ChevronRight,
  BriefcaseBusiness
} from "lucide-react";

import "./EscalatedHelp.css";

const initialCases = [
  {
    id: "472",
    phone: "5---S31A",
    step: "Step 3 of 5: Document NFC Scan",
    error: "NFC Failure Limit Exceeded (3/3)",
    code: "FLAG-NFC-083",
    status: "in_progress",
    duration: "Waiting: 4m 12s"
  },
  {
    id: "465",
    phone: "1---89ZE",
    step: "Step 4 of 5: Identity Video Verification",
    code: "PASS",
    status: "submitted",
    duration: "Submitted 12m ago"
  },
  {
    id: "458",
    phone: "3---S3J3",
    code: "ERR_SINGPASS_AGE_MISMATCH",
    status: "not_eligible",
    duration: "Escalated 28m ago"
  },
  {
    id: "451",
    phone: "7---674K",
    code: "TIMEOUT_STAGE_TAT_DEC",
    status: "abandoned",
    duration: "Escalated 45m ago"
  }
];

function EscalatedHelp({ onOpenChat }) {
  const [cases] = useState(initialCases);

  const pending = cases.filter(
    (item) => item.status === "in_progress"
  );

  const solved = cases.filter(
    (item) => item.status === "submitted"
  );

  const unable = cases.filter(
    (item) =>
      item.status === "not_eligible" ||
      item.status === "abandoned"
  );

  // Open Live Chat when staff clicks Continue
  const continueCase = (id) => {
    onOpenChat(id);
  };

  const viewSummary = (id) => {
    alert(`View summary for Applicant #${id}`);
  };

  return (
    <div className="eh-page">
      <div className="eh-page-header">
        <div>
          <div className="eh-title-row">
            <h1>Escalated to Staff Help</h1>
            <span className="eh-total">
              {cases.length} Cases Active
            </span>
          </div>

          <p>
            Review requests and take ownership of assistance
            across three distinct outcome status groups.
          </p>
        </div>

        <div className="eh-summary">
          <span className="eh-summary-blue">
            {pending.length} In Progress
          </span>

          <span className="eh-summary-green">
            {solved.length} Submitted
          </span>

          <span className="eh-summary-red">
            {unable.length} Ineligible / Dropped
          </span>
        </div>
      </div>

      {/* PENDING & ACTIVE REVIEW */}
      <section className="eh-group">
        <div className="eh-group-heading">
          <div className="eh-group-title">
            <span className="eh-marker blue" />

            <h2>Pending & Active Review</h2>

            <span className="eh-outcome blue">
              outcome: "in_progress"
            </span>

            <span className="eh-count">
              {pending.length} Case
            </span>
          </div>

          <small>
            Cases currently being investigated or awaiting
            staff action.
          </small>
        </div>

        <div className="eh-case-list">
          {pending.map((item) => (
            <div className="eh-case pending" key={item.id}>
              <div className="eh-applicant">
                <UserRound size={17} />

                <div>
                  <strong>Applicant #{item.id}</strong>
                  <small>{item.phone}</small>
                </div>
              </div>

              <div className="eh-case-info">
                <strong>
                  BLOCKED WORKFLOW STAGE: {item.step}
                </strong>

                <div className="eh-case-tags">
                  <span className="eh-warning-tag">
                    <AlertTriangle size={12} />
                    {item.error}
                  </span>

                  <code>{item.code}</code>
                </div>
              </div>

              <div className="eh-case-duration">
                <span>QUEUE DURATION</span>

                <strong className="eh-red-text">
                  <Clock3 size={13} />
                  {item.duration}
                </strong>
              </div>

              <div className="eh-buttons">
                <button
                  className="eh-outline-button"
                  onClick={() => viewSummary(item.id)}
                >
                  View Case
                  <ChevronRight size={14} />
                </button>

                <button
                  className="eh-red-button"
                  onClick={() => continueCase(item.id)}
                >
                  Continue
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SOLVED CASES */}
      <section className="eh-group">
        <div className="eh-group-heading">
          <div className="eh-group-title">
            <span className="eh-marker green" />

            <h2>Solved Cases</h2>

            <span className="eh-outcome green">
              ✓ Solved & Application Submitted
            </span>

            <span className="eh-count">
              {solved.length} Case
            </span>
          </div>

          <small>
            Frictions successfully resolved; onboarding
            application completed and submitted.
          </small>
        </div>

        <div className="eh-case-list">
          {solved.map((item) => (
            <div className="eh-case solved" key={item.id}>
              <div className="eh-applicant">
                <BriefcaseBusiness size={17} />

                <div>
                  <strong>Applicant #{item.id}</strong>
                  <small>{item.phone}</small>
                </div>
              </div>

              <div className="eh-case-info">
                <strong>
                  RESOLVED CHECKPOINT: {item.step}
                </strong>

                <div className="eh-case-tags">
                  <span className="eh-pass-tag">
                    {item.code}
                  </span>
                </div>
              </div>

              <div className="eh-case-duration">
                <span>OUTCOME STATUS</span>

                <strong className="eh-green-text">
                  100% Onboarded
                </strong>

                <small>{item.duration}</small>
              </div>

              <div className="eh-buttons">
                <button
                  className="eh-green-button"
                  onClick={() => viewSummary(item.id)}
                >
                  View Summary
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* UNABLE TO SOLVE */}
      <section className="eh-group">
        <div className="eh-group-heading">
          <div className="eh-group-title">
            <span className="eh-marker red" />

            <h2>Unable to Solve</h2>

            <span className="eh-outcome red">
              Outcome: "not_eligible"
            </span>

            <span className="eh-outcome amber">
              Outcome: "abandoned"
            </span>

            <span className="eh-count">
              {unable.length} Cases
            </span>
          </div>

          <small>
            Cases that ended without completion due to user
            drop-off or verification disqualification.
          </small>
        </div>

        <div className="eh-case-list unable">
          {unable.map((item) => (
            <div className="eh-case failed" key={item.id}>
              <div className="eh-applicant">
                {item.status === "not_eligible" ? (
                  <Ban size={17} />
                ) : (
                  <EyeOff size={17} />
                )}

                <div>
                  <strong>Applicant #{item.id}</strong>
                  <small>{item.phone}</small>
                </div>
              </div>

              <div className="eh-case-info">
                <div className="eh-case-tags">
                  <span
                    className={
                      item.status === "not_eligible"
                        ? "eh-failed-tag"
                        : "eh-abandoned-tag"
                    }
                  >
                    {item.status}
                  </span>

                  <code>{item.code}</code>
                </div>
              </div>

              <div className="eh-case-duration">
                <span>AUDIT MARKER</span>

                <strong>{item.duration}</strong>

                <small>
                  {item.status === "not_eligible"
                    ? "Account Issuance Blocked"
                    : "Session Dropped"}
                </small>
              </div>

              <div className="eh-buttons">
                <button
                  className="eh-failed-button"
                  onClick={() => viewSummary(item.id)}
                >
                  View Summary
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="eh-footer">
        <span>
          OCBC Enterprise Client Verification Architecture
          v4.12
        </span>

        <span>
          Connected Node: SG-ONB-PRD-04
        </span>

        <span className="eh-healthy">
          ● Singapore Telemetry Gateway Healthy
        </span>

        <span>
          All identity queries logged in accordance with
          MAS Technology Risk Management Guidelines
        </span>
      </footer>
    </div>
  );
}

export default EscalatedHelp;