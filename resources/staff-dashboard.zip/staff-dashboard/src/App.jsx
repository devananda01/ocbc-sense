
import { useState } from "react";

import Navbar from "./components/Navbar";
import FrictionQueue from "./pages/FrictionQueue";
import EscalatedHelp from "./pages/EscalatedHelp";
import LiveChat from "./pages/LiveChat";

import "./App.css";

function App() {
  const [activeTab, setActiveTab] = useState("friction");

  const [selectedApplicantId, setSelectedApplicantId] =
    useState(null);

  const openChat = (applicantId) => {
    setSelectedApplicantId(String(applicantId));
  };

  const closeChat = () => {
    setSelectedApplicantId(null);
    setActiveTab("friction");
  };

  // Existing standalone chat for Escalated Help
  if (selectedApplicantId !== null) {
    return (
      <LiveChat
        initialApplicantId={selectedApplicantId}
        onBack={closeChat}
      />
    );
  }

  return (
    <div className="app">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <main className="dashboard-content">
        <div
          style={{
            display: activeTab === "friction"
              ? "block"
              : "none"
          }}
        >
          <FrictionQueue />
        </div>

        {activeTab === "escalated" && (
          <EscalatedHelp onOpenChat={openChat} />
        )}
      </main>
    </div>
  );
}

export default App;