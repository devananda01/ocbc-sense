
import { useState } from "react";
import {
  Send,
  Paperclip,
  Phone,
  CheckCircle2,
  AlertTriangle,
  MessageSquare,
  Lightbulb,
  PanelRightClose,
  ShieldCheck
} from "lucide-react";

import "../pages/LiveChat.css";

const initialChats = [
  {
    id: "472",
    phone: "5---S31A",
    status: "Attention Needed",
    step: "Step 3: Document NFC Scan",
    messages: [
      {
        sender: "customer",
        text: "I've tried scanning my passport three times, but it keeps failing. Can you help?",
        time: "14:28"
      }
    ]
  },
  {
    id: "491",
    phone: "5---7988",
    status: "Attention Needed",
    step: "Step 3: Document NFC Scan",
    messages: [
      {
        sender: "customer",
        text: "Hi, every time I tap my IC to the phone, it says read failed. I've tried twice already and it won't proceed.",
        time: "14:24"
      },
      {
        sender: "staff",
        text: "Hello! Please try placing the top edge of your phone flat against the chip on the card and hold it still for 4 seconds without moving. Thick cases may also block the sensor.",
        time: "14:25"
      },
      {
        sender: "customer",
        text: "Let me take off my phone case and test again right now.",
        time: "14:26"
      }
    ]
  },
  {
    id: "488",
    phone: "1---142C",
    status: "In Progress",
    step: "Step 2: Mobile OTP Verification",
    messages: [
      {
        sender: "customer",
        text: "I haven't received my SMS verification code yet.",
        time: "14:20"
      }
    ]
  },
  {
    id: "485",
    phone: "5---890F",
    status: "In Progress",
    step: "Step 4: Initial Deposit",
    messages: [
      {
        sender: "customer",
        text: "Can I use PayNow or Wise for my initial deposit?",
        time: "14:17"
      }
    ]
  },
  {
    id: "479",
    phone: "3---C53A",
    status: "In Progress",
    step: "Step 3: Document NFC Scan",
    messages: [
      {
        sender: "customer",
        text: "Hi, I'm having trouble scanning my passport. Can you help me?",
        time: "14:20"
      }
    ]
  }
];

const suggestions = [
  "Hold phone flat over IC",
  "Remove thick phone cover",
  "Try Singpass MyInfo instead",
  "Session refreshed, please retry"
];

function EmbeddedChat({
  applicantId,
  onClose,
  onResolve
}) {
  const [chats, setChats] = useState(initialChats);
  const [drafts, setDrafts] = useState({});

  const selectedChat = chats.find(
    (chat) => chat.id === String(applicantId)
  );

  const message = drafts[String(applicantId)] || "";

  const updateMessage = (value) => {
    setDrafts((previous) => ({
      ...previous,
      [String(applicantId)]: value
    }));
  };

  const sendMessage = () => {
    if (!message.trim()) return;
    if (!selectedChat || selectedChat.status === "Resolved") {
      return;
    }

    const newMessage = {
      sender: "staff",
      text: message.trim(),
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
      })
    };

    setChats((previous) =>
      previous.map((chat) =>
        chat.id === String(applicantId)
          ? {
              ...chat,
              messages: [...chat.messages, newMessage]
            }
          : chat
      )
    );

    updateMessage("");
  };

  const resolveChat = () => {
    if (!selectedChat || selectedChat.status === "Resolved") {
      return;
    }

    setChats((previous) =>
      previous.map((chat) =>
        chat.id === String(applicantId)
          ? { ...chat, status: "Resolved" }
          : chat
      )
    );

    updateMessage("");
    onResolve?.(String(applicantId));
  };

  return (
    <section className="ec-panel">
      {/* CHAT HEADER */}
      <div className="ec-panel-heading">
        <div>
          <div className="ec-title">
            <span className="ec-online-dot" />
            <strong>Live Chat</strong>
          </div>
          <small>
            Staff Assistance · Sherry Lim
          </small>
        </div>

        <button
          type="button"
          className="ec-close-button"
          onClick={onClose}
          title="Collapse Live Chat"
          aria-label="Collapse Live Chat"
        >
          <PanelRightClose size={18} />
        </button>
      </div>

      {!selectedChat ? (
        <div className="ec-empty">
          No chat found for this applicant.
        </div>
      ) : (
        <>
          {/* CUSTOMER HEADER */}
          <div className="lc-customer-header">
            <div className="lc-customer-identity">
              <div className="lc-customer-avatar">
                A{selectedChat.id}
              </div>

              <div>
                <h2>
                  Applicant #{selectedChat.id}
                </h2>

                <p>
                  {selectedChat.phone} ·{" "}
                  {selectedChat.status === "Resolved"
                    ? "Resolved"
                    : "Active Now"}
                </p>

                <small>
                  {selectedChat.step}
                </small>
              </div>
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div className="ec-case-actions">
            <button
              type="button"
              className="lc-escalate"
              onClick={() =>
                alert(
                  `Escalate Applicant #${selectedChat.id}`
                )
              }
            >
              <Phone size={13} />
              Escalate Case
            </button>

            <button
              type="button"
              className="lc-resolve"
              onClick={resolveChat}
              disabled={selectedChat.status === "Resolved"}
            >
              <CheckCircle2 size={13} />
              {selectedChat.status === "Resolved"
                ? "Chat Resolved"
                : "Resolve & Close"}
            </button>
          </div>

          {/* CONVERSATION */}
          <div className="lc-conversation">
            <div className="lc-date-divider">
              Today
            </div>

            {selectedChat.id === "491" && (
              <div className="lc-system-alert">
                <AlertTriangle size={15} />
                <span>
                  Friction detected: NFC Scan Timeout
                  (NFC_TIMEOUT_04).
                </span>
              </div>
            )}

            {selectedChat.id === "472" && (
              <div className="lc-system-alert">
                <AlertTriangle size={15} />
                <span>
                  Friction detected: NFC Failure
                  Limit Exceeded (3/3).
                </span>
              </div>
            )}

            <div className="lc-messages">
              {selectedChat.messages.map((item, index) => (
                <div
                  key={index}
                  className={`lc-message-row ${item.sender}`}
                >
                  <div className="lc-message-content">
                    <div className="lc-message-meta">
                      <strong>
                        {item.sender === "staff"
                          ? "Sherry Lim"
                          : `Applicant #${selectedChat.id}`}
                      </strong>
                      <span>{item.time}</span>
                    </div>

                    <div className="lc-bubble">
                      {item.text}
                    </div>

                    {item.sender === "staff" && (
                      <small className="lc-delivered">
                        ✓ Sent (demo)
                      </small>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SUGGESTED REPLIES */}
          <div className="lc-suggestions">
            <Lightbulb size={14} />
            <span>Suggested:</span>

            {suggestions.map((suggestion) => (
              <button
                type="button"
                key={suggestion}
                onClick={() => updateMessage(suggestion)}
                disabled={selectedChat.status === "Resolved"}
              >
                {suggestion}
              </button>
            ))}
          </div>

          {/* MESSAGE INPUT */}
          <div className="lc-input-area">
            <button
              type="button"
              className="lc-attach"
              title="Attachments"
              onClick={() =>
                alert("Attachment feature coming soon")
              }
            >
              <Paperclip size={16} />
            </button>

            <button
              type="button"
              className="lc-attach"
              title="Quick replies"
              onClick={() =>
                alert("Quick replies coming soon")
              }
            >
              <MessageSquare size={16} />
            </button>

            <input
              placeholder="Type a response..."
              value={message}
              onChange={(e) =>
                updateMessage(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  sendMessage();
                }
              }}
              disabled={selectedChat.status === "Resolved"}
            />

            <button
              type="button"
              className="lc-send"
              onClick={sendMessage}
              disabled={
                !message.trim() ||
                selectedChat.status === "Resolved"
              }
              aria-label="Send message"
            >
              <Send size={16} />
            </button>
          </div>

          {/* FOOTER */}
          <footer className="lc-footer">
            <span>
              <ShieldCheck size={12} />
              Demo chat session
            </span>
            <span>OCBC Sense</span>
          </footer>
        </>
      )}
    </section>
  );
}

export default EmbeddedChat;