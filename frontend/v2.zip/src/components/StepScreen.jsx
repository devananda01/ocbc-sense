import { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import Screen from './Screen'
import Header from './Header'
import StepList from './StepList'
import ProgressBar from './ProgressBar'
import AskSenseButton from './AskSenseButton'
import StatusBanner from './StatusBanner'
import { useHelp } from '../context/HelpContext'
import { getPage } from '../data/content'
import { TIPS } from '../data/answers'
import './StepScreen.css'

const STEP_TITLES = [1, 2, 3, 4, 5, 6].map((n) => getPage(`account.step${n}`).title)

export default function StepScreen({ step, onBack, footer, progressRight, children }) {
  const navigate = useNavigate()
  const { openHelp, level } = useHelp()
  const guideRef = useRef(null)

  // Level 2: glow the main button (and show the arrow) if it can be pressed.
  useEffect(() => {
    const el = guideRef.current
    if (!el) return
    el.classList.toggle('guide--on', level >= 2 && !!el.querySelector('.btn--primary:not(:disabled)'))
  })

  return (
    <Screen
      header={<Header onBack={onBack} onSettings={() => navigate('/settings')} />}
      aside={<StepList steps={STEP_TITLES} current={step} />}
      footer={
        <>
          <div className="guide" ref={guideRef}>
            <span className="guide__pill" aria-hidden="true">Start here ↓</span>
            {footer}
          </div>
          <AskSenseButton onClick={openHelp} />
        </>
      }
    >
      <ProgressBar current={step} right={progressRight} />
      {level >= 1 && TIPS[`account.step${step}`] && (
        <StatusBanner variant="tip" label="A hint for this step">{TIPS[`account.step${step}`]}</StatusBanner>
      )}
      {children}
    </Screen>
  )
}